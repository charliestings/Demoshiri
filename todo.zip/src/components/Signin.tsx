"use client";

import { useSession, signIn, signOut } from "next-auth/react";

export default function Signin() {
  const { data: session } = useSession();

  // 👉 If NOT logged in
  if (!session) {
    return (
      <button
        onClick={() => signIn("google")}
        className="px-4 py-2 bg-blue-500 text-white rounded"
      >
        Sign in with Google
      </button>
    );
  }

  // 👉 If logged in, show user details
  return (
    <div className="flex flex-col items-start gap-2">
      <p><b>Logged in as:</b> {session.user?.name}</p>
      <p><b>Email:</b> {session.user?.email}</p>
      {session.user?.image && (
        <img
          src={session.user.image}
          alt="user"
          className="w-16 h-16 rounded-full"
        />
      )}

      <button
        onClick={() => signOut()}
        className="px-4 py-2 bg-red-500 text-white rounded"
      >
        Sign Out
      </button>
    </div>
  );
}
