function Hello(){
    return(
        <div>
            <h2>Good Night</h2>
        </div>
    )
}
function HelloWorld(){
    return(
        <div>
            <h2>Good Morning</h2>
        </div>
    )
}
export default Hello;
export {HelloWorld};