import { NextAuthOptions } from "next-auth";
import GoogleProvider from "next-auth/providers/google";
import {supabaseServer} from "@/lib/supabaseServer";

export const authOptions: NextAuthOptions = {
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID as string,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET as string,
    }),
  ],

  callbacks: {
    async signIn({ user }) {
      if (!user?.email) return false;
      console.log("User",user)
      // 1. Check if user already exists
      const { data: existingUser } = await supabaseServer
        .from("users")
        .select("*")
        .eq("email", user.email)
        .single();
      console.log("Existing user",existingUser)
      // 2. If user does NOT exist → create new user
      if (!existingUser) {
        await supabaseServer.from("users").insert({
          id: user.id,         // google id or nextauth id
          name: user.name,
          email: user.email,
          image: user.image
        });
      }

      return true; // allow login
    },

    async session({ session, token }) {
      if (session.user) {
        session.user.id = token.sub as string;
      }
      return session;
    },
  },
};
